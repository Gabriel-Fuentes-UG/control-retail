// src/app/operaciones/receptions/page.tsx
"use client";

import { useState, useMemo } from "react";
import { Button } from "react-bootstrap";
import Breadcrumbs from "@/components/layout/Breadcrumbs";
import IncomingTransfersList from "@/components/receptions/IncomingTransfersList";
import TransferDetailView from "@/components/receptions/TransferDetailView";

type Step = 'selection' | 'list' | 'detail';

export default function ReceptionsPage() {
  const [step, setStep] = useState<Step>('selection');
  const [selectedFolio, setSelectedFolio] = useState<number | null>(null);

  const handleTransferSelect = (folio: number) => {
    setSelectedFolio(folio);
    setStep('detail');
  };

  const handleReturnToList = () => {
    setSelectedFolio(null);
    setStep('list');
  };

  // Usamos useMemo para construir los breadcrumbs de forma segura
  const breadcrumbItems = useMemo(() => {
    const baseCrumbs = [
      { label: "Inicio", href: "/redirect-hub" },
      { 
        label: "Recepciones", 
        // El enlace para volver al paso 1 solo está activo si no estamos en el paso 1
        href: step !== 'selection' ? '#' : undefined,
        onClick: step !== 'selection' ? () => setStep('selection') : undefined 
      }
    ];

    if (step === 'list') {
      baseCrumbs.push({ label: "Lista de Traslados" });
    } else if (step === 'detail' && selectedFolio) {
      baseCrumbs.push({ 
        label: "Lista de Traslados",
        href: '#',
        onClick: handleReturnToList
      });
      baseCrumbs.push({ label: `Detalle Folio ${selectedFolio}` });
    }
    
    return baseCrumbs;
  }, [step, selectedFolio]); // Se recalcula solo cuando cambian estas dependencias


  // Renderizamos el contenido de cada paso
  let currentStepContent;
  switch(step) {
    case 'list':
      currentStepContent = <IncomingTransfersList onTransferSelect={handleTransferSelect} />;
      break;
    case 'detail':
      // El botón de regreso ahora estará en el componente de detalle
      currentStepContent = selectedFolio ? <TransferDetailView folioSAP={selectedFolio} onBack={handleReturnToList} /> : null;
      break;
    case 'selection':
    default:
      currentStepContent = (
        <div>
          <p>Por favor, selecciona el origen de la mercancía:</p>
          <Button 
            variant="primary" 
            className="me-2" 
            onClick={() => setStep('list')}
          >
            Centro de Distribución / Traslado
          </Button>
        </div>
      );
  }

  return (
    <div className="dashboard-section">
      <Breadcrumbs items={breadcrumbItems} />
      <div className="d-flex justify-content-between align-items-center my-4">
        <h2>Iniciar Recepción de Mercancía</h2>
      </div>
      {currentStepContent}
    </div>
  );
}