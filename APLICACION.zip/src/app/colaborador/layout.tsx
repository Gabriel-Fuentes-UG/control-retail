// src/app/colaborador/layout.tsx
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import AppShell from "@/components/layout/AppShell";

export default async function StaffLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);
  const role = session?.user?.role;

  // Sólo COLABORADOR o VENDEDOR pueden entrar aquí
  if (!session || (role !== "ENCARGADO" && role !== "VENDEDOR")) {
    redirect("/");
  }

  return <AppShell>{children}</AppShell>;
}
