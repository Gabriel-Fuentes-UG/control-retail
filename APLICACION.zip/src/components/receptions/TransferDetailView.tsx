// src/components/receptions/TransferDetailView.tsx
"use client";

// CORRECCIÓN 1: Importamos los hooks desde 'react'
import { useEffect, useState, useTransition, useRef } from "react";
import { 
  getTransferDetailsAction, 
  TransferDetail,
  confirmReceptionAction
} from "@/app/operaciones/receptions/actions";
import { Table, Spinner, Form, Button, Alert } from "react-bootstrap";
import { useActionState } from "react"; // Importación corregida a 'react'

// Añadimos las nuevas propiedades a nuestro tipo de detalle para la conciliación
type ReconciliationItem = TransferDetail & {
  quantityReceived: string;
};

// Añadimos onBack para poder regresar a la lista
export default function TransferDetailView({ folioSAP, onBack }: { folioSAP: number, onBack: () => void }) {
  const [items, setItems] = useState<ReconciliationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // CORRECCIÓN 2: Usamos useTransition para llamar a la acción de forma segura
  const [isPending, startTransition] = useTransition();
  const [state, formAction] = useActionState(confirmReceptionAction, undefined);

  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    setIsLoading(true);
    getTransferDetailsAction(folioSAP).then(response => {
        if (response.error) {
            setError(response.error);
        } else if (response.data) {
            const initialItems = response.data.map(item => ({
                ...item,
                quantityReceived: String(item.Cantidad),
              }));
            setItems(initialItems);
        }
        setIsLoading(false);
      });
  }, [folioSAP]);

  const handleQuantityChange = (lineNum: number, newQuantity: string) => {
    const quantity = newQuantity === '' ? '' : newQuantity;
    setItems(currentItems =>
      currentItems.map(item =>
        item.Linenum === lineNum ? { ...item, quantityReceived: quantity } : item
      )
    );
  };

  const handleConfirm = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (formRef.current) {
        const formData = new FormData(formRef.current);
        // CORRECCIÓN 3: Envolvemos la llamada a la acción en startTransition
        startTransition(() => {
            formAction(formData);
        });
    }
  }

  if (isLoading) return <div className="text-center p-5"><Spinner animation="border" /> <p>Cargando detalle del traslado...</p></div>;
  if (error) return <Alert variant="danger">{error}</Alert>

  return (
    <div className="mt-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
            <h4>Conciliación de Mercancía (Folio SAP: {folioSAP})</h4>
            <Button variant="outline-secondary" onClick={onBack}>
                &larr; Volver a la lista
            </Button>
        </div>

        {/* El onSubmit ahora llama a nuestra función handleConfirm */}
        <Form ref={formRef} onSubmit={handleConfirm}>
            <input type="hidden" name="folioSAP" value={folioSAP} />

            <Table striped bordered hover responsive className="align-middle">
                <thead>
                    <tr>
                        <th>Artículo</th>
                        <th>Descripción</th>
                        <th className="text-center">Cant. Esperada</th>
                        <th className="text-center" style={{maxWidth: '150px'}}>Cant. Recibida</th>
                        <th className="text-center">Diferencia</th>
                        <th className="text-center">Estatus</th>
                    </tr>
                </thead>
                <tbody>
                    {items.map((item, index) => {
                        const quantityNum = parseInt(item.quantityReceived) || 0;
                        const difference = quantityNum - item.Cantidad;
                        let statusBadge = 'bg-success';
                        if (difference < 0) statusBadge = 'bg-danger';
                        if (difference > 0) statusBadge = 'bg-warning text-dark';
                        
                        return (
                        <tr key={item.Linenum}>
                            <td>{item.Articulo}</td>
                            <td>{item.Descripcion}</td>
                            <td className="text-center">{item.Cantidad}</td>
                            <td>
                                <input type="hidden" name={`items[${index}][articulo]`} value={item.Articulo} />
                                <input type="hidden" name={`items[${index}][esperado]`} value={item.Cantidad} />
                                <Form.Control 
                                    type="number" 
                                    name={`items[${index}][recibido]`}
                                    value={item.quantityReceived}
                                    onChange={(e) => handleQuantityChange(item.Linenum, e.target.value)}
                                    className="text-center"
                                    min="0"
                                />
                            </td>
                            <td className="text-center fw-bold">{difference !== 0 ? difference : '-'}</td>
                            <td className="text-center">
                                <span className={`badge ${statusBadge}`}>
                                    {difference === 0 ? 'Correcto' : (difference > 0 ? `Excedente` : 'Faltante')}
                                </span>
                            </td>
                        </tr>
                        );
                    })}
                </tbody>
            </Table>
            {state?.message && <Alert variant={state.success ? 'success' : 'danger'}>{state.message}</Alert>}
            <div className="d-flex justify-content-end mt-4">
                <Button variant="secondary" className="me-2" onClick={onBack} disabled={isPending}>Cancelar</Button>
                <Button variant="primary" type="submit" disabled={isPending}>
                    {isPending ? (<><Spinner as="span" size="sm" /> Procesando...</>) : 'Confirmar Recepción'}
                </Button>
            </div>
        </Form>
    </div>
  );
}