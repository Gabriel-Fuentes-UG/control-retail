// src/components/receptions/IncomingTransfersList.tsx
"use client";

import { useEffect, useState, useMemo } from "react";
import { getIncomingTransfersAction, getSupervisorManagedStoresAction, IncomingTransfer } from "@/app/operaciones/receptions/actions";
import { Row, Col, Form, InputGroup, Spinner } from "react-bootstrap";
import { useSession } from "next-auth/react";
import TransferCard from "./TransferCard";
import { Store } from "@prisma/client";

export default function IncomingTransfersList({ onTransferSelect }: { onTransferSelect: (folio: number) => void }) {
  const { data: session } = useSession();
  const [transfers, setTransfers] = useState<IncomingTransfer[]>([]);
  const [managedStores, setManagedStores] = useState<Store[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [storeFilter, setStoreFilter] = useState('all');

  useEffect(() => {
    Promise.all([
      getIncomingTransfersAction(),
      getSupervisorManagedStoresAction()
    ]).then(([transferData, storeData]) => {
      setTransfers(transferData);
      setManagedStores(storeData);
      setIsLoading(false);
    });
  }, []);

  const filteredTransfers = useMemo(() => {
    let results = transfers;
    if (storeFilter !== 'all') {
      results = results.filter(t => t.AlmacenDestino === storeFilter);
    }
    if (searchTerm) {
      results = results.filter(t => t.FolioSAP.toString().includes(searchTerm));
    }
    return results;
  }, [transfers, searchTerm, storeFilter]);

  const uniqueStores = useMemo(() => {
    if (session?.user?.role !== 'SUPERVISOR') return [];
    const storesMap = new Map();
    managedStores.forEach(store => {
      if (!storesMap.has(store.id)) {
        storesMap.set(store.id, store);
      }
    });
    return Array.from(storesMap.values());
  }, [managedStores, session]);


  if (isLoading) return <div className="text-center p-5"><Spinner animation="border" /> <p>Buscando traslados pendientes...</p></div>;

  return (
    <div className="mt-4">
      <h4>Selecciona un Traslado Pendiente</h4>
      <Row>
        <Col md={5} lg={4} className="mb-3">
          <InputGroup><Form.Control placeholder="Buscar por Folio SAP..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></InputGroup>
        </Col>
        {session?.user?.role === 'SUPERVISOR' && uniqueStores.length > 0 && (
          <Col md={5} lg={4} className="mb-3">
            <Form.Group controlId="storeFilter">
              <Form.Label>Filtrar por Tienda</Form.Label>
              <Form.Select value={storeFilter} onChange={e => setStoreFilter(e.target.value)}>
                <option value="all">Ver Todas Mis Tiendas</option>
                {uniqueStores.map(store => ( <option key={store.id} value={store.id}>{store.name}</option> ))}
              </Form.Select>
            </Form.Group>
          </Col>
        )}
      </Row>
      <Row className="g-3">
        {filteredTransfers.length > 0 ? filteredTransfers.map(t => (
          <Col md={6} lg={3} key={t.FolioSAP}>
            {/* Aquí nos aseguramos de pasar la función correcta al hacer clic */}
            <TransferCard transfer={t} onSelect={() => onTransferSelect(t.FolioSAP)} />
          </Col>
        )) : <Col><p>No se encontraron traslados pendientes.</p></Col>}
      </Row>
    </div>
  );
}